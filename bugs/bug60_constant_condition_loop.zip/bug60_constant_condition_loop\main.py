import base64, struct

def run():
    acc = 0xC0C0C0C0C0C0C0C0
    i = 0
    while True:
        acc ^= i * 0x9E3779B97F4A7C15
        acc &= 0xFFFFFFFFFFFFFFFF
        acc = ((acc << (i % 11 + 1)) | (acc >> (63 - i % 11))) & 0xFFFFFFFFFFFFFFFF
        i += 1
    raw = struct.pack(">Q", acc)
    print(base64.b64encode(raw).decode())

run()
