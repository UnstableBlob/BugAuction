**Error:** The script fails due to an error in the implementation.

**Hint:** Constant condition loop.
