function main() {
    let acc = 0xC0C0C0C0C0C0C0C0n;
    let i = 0n;
    while (true) {
        acc ^= i * 0x9E3779B97F4A7C15n;
        acc &= 0xFFFFFFFFFFFFFFFFn;
        acc = ((acc << (i % 11n + 1n)) | (acc >> (63n - i % 11n))) & 0xFFFFFFFFFFFFFFFFn;
        i += 1n;
    }
}
main();
