#include <iostream>

int main() {
    unsigned long long acc = 0xC0C0C0C0C0C0C0C0ULL;
    unsigned long long i = 0;
    while (1) {
        acc ^= i * 0x9E3779B97F4A7C15ULL;
        acc = ((acc << (i % 11 + 1)) | (acc >> (63 - i % 11)));
        i += 1;
    }
    return 0;
}
