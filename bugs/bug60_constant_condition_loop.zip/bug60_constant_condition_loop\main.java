public class main {
    public static void main(String[] args) {
        long acc = 0xC0C0C0C0C0C0C0C0L;
        long i = 0;
        while (true) {
            acc ^= i * 0x9E3779B97F4A7C15L;
            acc = ((acc << (i % 11 + 1)) | (acc >>> (63 - (i % 11))));
            i += 1;
        }
    }
}
