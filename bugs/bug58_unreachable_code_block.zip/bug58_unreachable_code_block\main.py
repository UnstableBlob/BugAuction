import base64, struct

def run():
    acc = 0xBADC0FFEE0DDF00D
    for i in range(10):
        acc ^= i * 0x9E3779B97F4A7C15
        acc &= 0xFFFFFFFFFFFFFFFF
        return acc
        acc = ((acc << (i % 9 + 1)) | (acc >> (63 - i % 9))) & 0xFFFFFFFFFFFFFFFF
        acc *= 0xBF58476D1CE4E5B9
        acc &= 0xFFFFFFFFFFFFFFFF

correct = 0xBADC0FFEE0DDF00D
for i in range(10):
    correct ^= i * 0x9E3779B97F4A7C15
    correct &= 0xFFFFFFFFFFFFFFFF
    correct = ((correct << (i % 9 + 1)) | (correct >> (63 - i % 9))) & 0xFFFFFFFFFFFFFFFF
    correct *= 0xBF58476D1CE4E5B9
    correct &= 0xFFFFFFFFFFFFFFFF

result = run()
if result == correct:
    raise AssertionError("unreachable code same result")
raise ValueError(f"return inside loop made rest of body unreachable: got {result:#x} expected {correct:#x}")
