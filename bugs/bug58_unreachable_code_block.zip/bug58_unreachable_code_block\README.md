**Error:** Return inside loop made rest of body unreachable.

**Hint:** Unreachable code block.
