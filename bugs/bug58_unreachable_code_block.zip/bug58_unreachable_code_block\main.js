function run_buggy() {
    let acc = 0xBADC0FFEE0DDF00Dn;
    for (let i = 0n; i < 10n; i++) {
        acc ^= i * 0x9E3779B97F4A7C15n;
        acc &= 0xFFFFFFFFFFFFFFFFn;
        return acc;
        acc = ((acc << (i % 9n + 1n)) | (acc >> (63n - (i % 9n)))) & 0xFFFFFFFFFFFFFFFFn;
        acc = (acc * 0xBF58476D1CE4E5B9n) & 0xFFFFFFFFFFFFFFFFn;
    }
    return acc;
}

function main() {
    let correct = 0xBADC0FFEE0DDF00Dn;
    for (let i = 0n; i < 10n; i++) {
        correct ^= i * 0x9E3779B97F4A7C15n;
        correct &= 0xFFFFFFFFFFFFFFFFn;
        correct = ((correct << (i % 9n + 1n)) | (correct >> (63n - (i % 9n)))) & 0xFFFFFFFFFFFFFFFFn;
        correct = (correct * 0xBF58476D1CE4E5B9n) & 0xFFFFFFFFFFFFFFFFn;
    }
    
    let result = run_buggy();
    if (result === correct) {
        console.error("AssertionError: unreachable code same result");
        process.exit(1);
    }
    console.error(`ValueError: return inside loop made rest of body unreachable: got 0x${result.toString(16)} expected 0x${correct.toString(16)}`);
    process.exit(1);
}

main();
