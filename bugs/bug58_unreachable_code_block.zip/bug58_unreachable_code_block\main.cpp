#include <iostream>

unsigned long long run_buggy() {
    unsigned long long acc = 0xBADC0FFEE0DDF00DULL;
    for (int i = 0; i < 10; i++) {
        acc ^= i * 0x9E3779B97F4A7C15ULL;
        return acc;
        acc = ((acc << (i % 9 + 1)) | (acc >> (63 - i % 9)));
        acc *= 0xBF58476D1CE4E5B9ULL;
    }
    return acc;
}

int main() {
    unsigned long long correct = 0xBADC0FFEE0DDF00DULL;
    for (int i = 0; i < 10; i++) {
        correct ^= i * 0x9E3779B97F4A7C15ULL;
        correct = ((correct << (i % 9 + 1)) | (correct >> (63 - i % 9)));
        correct *= 0xBF58476D1CE4E5B9ULL;
    }
    
    unsigned long long result = run_buggy();
    if (result == correct) {
        std::cerr << "AssertionError: unreachable code same result\n";
        return 1;
    }
    char buffer[256];
    snprintf(buffer, sizeof(buffer), "ValueError: return inside loop made rest of body unreachable: got 0x%llx expected 0x%llx", result, correct);
    std::cerr << buffer << "\n";
    return 1;
}
