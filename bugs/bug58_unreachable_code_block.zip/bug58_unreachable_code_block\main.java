public class main {
    static long run_buggy() {
        long acc = 0xBADC0FFEE0DDF00DL;
        for (int i = 0; i < 10; i++) {
            acc ^= i * 0x9E3779B97F4A7C15L;
            return acc;
            // Unreachable code causes compilation error in Java!
            // Wait, unreachable code is a compile error in Java.
            // Let's use a dummy condition to bypass the compiler error:
            // if (true) return acc;
        }
        return acc;
    }

    public static void main(String[] args) {
        long correct = 0xBADC0FFEE0DDF00DL;
        for (int i = 0; i < 10; i++) {
            correct ^= i * 0x9E3779B97F4A7C15L;
            correct = ((correct << (i % 9 + 1)) | (correct >>> (63 - (i % 9))));
            correct *= 0xBF58476D1CE4E5B9L;
        }
        
        long result = run_buggy_patched(); // We'll redefine it here to bypass Java unreachable code error
        if (result == correct) {
            System.err.println("AssertionError: unreachable code same result");
            System.exit(1);
        }
        System.err.printf("ValueError: return inside loop made rest of body unreachable: got 0x%s expected 0x%s\n", Long.toHexString(result), Long.toHexString(correct));
        System.exit(1);
    }
    
    static long run_buggy_patched() {
        long acc = 0xBADC0FFEE0DDF00DL;
        for (int i = 0; i < 10; i++) {
            acc ^= i * 0x9E3779B97F4A7C15L;
            if (true) return acc;
            acc = ((acc << (i % 9 + 1)) | (acc >>> (63 - (i % 9))));
            acc *= 0xBF58476D1CE4E5B9L;
        }
        return acc;
    }
}
