#include <stdio.h>
#include <stdint.h>

static const uint64_t MAGIC = 0x9E3779B97F4A7C15ULL;

/* BUG: exponential recursion with n=200 causes stack overflow */
uint64_t fib_hash(int n) {
    if (n <= 1) return (uint64_t)n * MAGIC;
    return (fib_hash(n - 1) + fib_hash(n - 2));
}

int main(void) {
    /* This will crash with stack overflow (or run forever) */
    uint64_t result = fib_hash(200);
    printf("0x%llx\n", (unsigned long long)result);
    return 0;
}
