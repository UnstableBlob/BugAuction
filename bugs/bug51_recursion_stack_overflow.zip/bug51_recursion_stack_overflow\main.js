// BUG: exponential recursion - fib(200) causes RangeError: Maximum call stack size exceeded
const MAGIC = 0x9E3779B9n * (2n**32n) + 0x7F4A7C15n;
const MASK = 0xFFFFFFFFFFFFFFFFn;

function fibHash(n) {
    if (n <= 1) return (BigInt(n) * MAGIC) & MASK;
    return (fibHash(n - 1) + fibHash(n - 2)) & MASK;
}

try {
    const result = fibHash(200);
    process.stdout.write(`0x${result.toString(16)}\n`);
} catch (e) {
    process.stderr.write(`${e.constructor.name}: ${e.message}\n`);
    process.exit(1);
}
