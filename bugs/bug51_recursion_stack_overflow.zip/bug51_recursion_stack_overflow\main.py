import base64, struct
import sys
sys.setrecursionlimit(100)

def fib_hash(n):
    if n <= 1:
        return n * 0x9E3779B97F4A7C15 & 0xFFFFFFFFFFFFFFFF
    return (fib_hash(n - 1) + fib_hash(n - 2)) & 0xFFFFFFFFFFFFFFFF

result = fib_hash(200)
raw = struct.pack(">Q", result)
print(base64.b64encode(raw).decode())
