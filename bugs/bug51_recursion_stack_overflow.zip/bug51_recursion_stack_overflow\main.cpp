#include <iostream>
#include <cstdint>

static const uint64_t MAGIC = 0x9E3779B97F4A7C15ULL;

/* BUG: exponential recursion with n=200 causes stack overflow */
uint64_t fib_hash(int n) {
    if (n <= 1) return (uint64_t)n * MAGIC;
    return (fib_hash(n - 1) + fib_hash(n - 2));
}

int main() {
    uint64_t result = fib_hash(200);
    std::cout << std::hex << result << std::endl;
    return 0;
}
