import java.util.Base64;
import java.nio.ByteBuffer;

public class Main {
    static final long MAGIC = 0x9E3779B97F4A7C15L;

    /* BUG: exponential recursion with n=200 causes StackOverflowError */
    static long fibHash(int n) {
        if (n <= 1) return (long)n * MAGIC;
        return fibHash(n - 1) + fibHash(n - 2);
    }

    public static void main(String[] args) {
        try {
            long result = fibHash(200);
            System.out.println(Long.toHexString(result));
        } catch (StackOverflowError e) {
            System.err.println("StackOverflowError: fib(200) with naive recursion overflows the stack");
            System.exit(1);
        }
    }
}
