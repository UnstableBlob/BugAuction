import base64, struct

def process(seed, factor):
    acc = seed
    for i in range(10):
        acc ^= i * factor
        acc = (acc * 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF
        acc = ((acc << (i % 9 + 1)) | (acc >> (63 - i % 9))) & 0xFFFFFFFFFFFFFFFF
    return acc

seed   = 0xBEEFDEAD87654321
factor = 0xABCDEF1234567890

result  = process(seed, 1)
correct = process(seed, factor)
if result == correct:
    raise AssertionError("constant 1 same as factor")
raise ValueError(f"constant 1 passed instead of factor: got {result:#x} expected {correct:#x}")
