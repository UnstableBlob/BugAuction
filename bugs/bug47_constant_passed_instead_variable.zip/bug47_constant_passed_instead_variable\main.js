// BUG: constant 1 passed instead of factor variable
const MAGIC = 0x9E3779B9n * (2n**32n) + 0x7F4A7C15n;
const MASK = 0xFFFFFFFFFFFFFFFFn;

function compute(seed, factor) {
    let acc = seed;
    for (let i = 0n; i < 10n; i++) {
        acc ^= i * factor;
        acc = (acc * MAGIC) & MASK;
        const shift = Number(i % 9n) + 1;
        acc = ((acc << BigInt(shift)) | (acc >> BigInt(64 - shift))) & MASK;
    }
    return acc;
}

const seed   = 0xBEEFDEADn * (2n**32n) + 0x87654321n;
const factor = 0xABCDEF12n * (2n**32n) + 0x34567890n;

/* BUG: constant 1n passed instead of factor */
const result  = compute(seed, 1n);
const correct = compute(seed, factor);

if (result === correct) {
    process.stderr.write("AssertionError: constant 1 same as factor\n");
    process.exit(1);
}
process.stderr.write(`ValueError: constant 1 passed instead of factor: got 0x${result.toString(16)} expected 0x${correct.toString(16)}\n`);
process.exit(1);
