#include <stdio.h>
#include <stdint.h>

static const uint64_t MAGIC = 0x9E3779B97F4A7C15ULL;

uint64_t process(uint64_t seed, uint64_t factor) {
    uint64_t acc = seed;
    for (int i = 0; i < 10; i++) {
        acc ^= (uint64_t)i * factor;
        acc = acc * MAGIC;
        int shift = i % 9 + 1;
        acc = ((acc << shift) | (acc >> (64 - shift)));
    }
    return acc;
}

int main(void) {
    uint64_t seed   = 0xBEEFDEAD87654321ULL;
    uint64_t factor = 0xABCDEF1234567890ULL;

    /* BUG: constant 1 passed instead of factor */
    uint64_t result  = process(seed, 1);
    uint64_t correct = process(seed, factor);

    if (result == correct) {
        fprintf(stderr, "AssertionError: constant 1 same as factor\n");
        return 1;
    }
    fprintf(stderr, "ValueError: constant 1 passed instead of factor: got 0x%llx expected 0x%llx\n",
            (unsigned long long)result, (unsigned long long)correct);
    return 1;
}
