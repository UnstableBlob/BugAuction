**Error:** Constant 1 passed instead of factor.

**Hint:** Constant passed instead variable.
