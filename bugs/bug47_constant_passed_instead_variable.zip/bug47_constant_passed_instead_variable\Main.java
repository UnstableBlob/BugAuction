import java.util.Base64;
import java.nio.ByteBuffer;

public class Main {
    static final long MAGIC = 0x9E3779B97F4A7C15L;

    static long process(long seed, long factor) {
        long acc = seed;
        for (int i = 0; i < 10; i++) {
            acc ^= (long)i * factor;
            acc = acc * MAGIC;
            int shift = i % 9 + 1;
            acc = (acc << shift) | (acc >>> (64 - shift));
        }
        return acc;
    }

    public static void main(String[] args) {
        long seed   = 0xBEEFDEAD87654321L;
        long factor = 0xABCDEF1234567890L;

        /* BUG: constant 1 passed instead of factor */
        long result  = process(seed, 1);
        long correct = process(seed, factor);

        if (result == correct) {
            System.err.println("AssertionError: constant 1 same as factor");
            System.exit(1);
        }
        System.err.printf("ValueError: constant 1 passed instead of factor: got 0x%x expected 0x%x%n", result, correct);
        System.exit(1);
    }
}
