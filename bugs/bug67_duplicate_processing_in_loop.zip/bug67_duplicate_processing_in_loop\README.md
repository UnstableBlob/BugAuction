**Error:** Xor applied twice cancels itself.

**Hint:** Duplicate processing in loop.
