// Bug: using string values without converting to integer — TypeError equivalent
function run() {
    const rawVals = [
        "305419896", "2596069104", "3735928559",
        "3203399405", "4275878552", "2882400018",
        "3735928495", "3203391149", "3722304989", "4048432193"
    ];
    let acc = 0xFACEFEEDDEADBEEFn;
    for (let i = 0; i < rawVals.length; i++) {
        /* Bug: using the string directly instead of BigInt(rawVals[i]) */
        let v = rawVals[i]; /* should be BigInt(rawVals[i]) */
        try {
            /* Attempting bitwise operation on string — TypeError in Python equivalent */
            let shifted = BigInt(v) << BigInt(i % 8); /* This works in JS but simulate the bug */
            /* The real bug: v is not converted — detect and raise */
            if (typeof v === 'string') {
                throw new TypeError("unsupported operand type(s) for <<: 'str' and 'int'");
            }
        } catch (e) {
            if (e instanceof TypeError) {
                console.error("TypeError: " + e.message);
                process.exit(1);
            }
        }
    }
}

run();
