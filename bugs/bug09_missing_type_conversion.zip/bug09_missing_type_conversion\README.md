**Error:** The script fails with a `TypeError: unsupported operand type(s) for <<: 'str' and 'int'` because it attempts to perform bitwise operations on strings instead of integers.

**Hint:** Missing type conversion.
