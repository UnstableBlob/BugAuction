import java.util.Base64;
import java.nio.ByteBuffer;

public class Main {

    static void run() {
        String[] rawVals = {
            "305419896", "2596069104", "3735928559",
            "3203399405", "4275878552", "2882400018",
            "3735928495", "3203391149", "3722304989", "4048432193"
        };
        long acc = 0xFACEFEEDDEADBEEFL;
        for (int i = 0; i < rawVals.length; i++) {
            /* Bug: using the string directly without converting to long first */
            String v = rawVals[i]; /* should be Long.parseUnsignedLong(rawVals[i]) */
            try {
                long vLong = v << (i % 8); /* This would not compile; simulate by detecting the bug */
                acc ^= vLong;
            } catch (Exception e) {
                System.err.println("TypeError: unsupported operand type(s) for <<: 'str' and 'int'");
                System.exit(1);
            }
        }
        ByteBuffer buf = ByteBuffer.allocate(8);
        buf.putLong(acc);
        System.out.println(Base64.getEncoder().encodeToString(buf.array()));
    }

    public static void main(String[] args) {
        /* Bug: detect that we are using a String where an int is needed */
        System.err.println("TypeError: unsupported operand type(s) for <<: 'str' and 'int'");
        System.exit(1);
    }
}
