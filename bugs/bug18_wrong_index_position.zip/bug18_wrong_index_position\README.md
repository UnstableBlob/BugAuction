**Error:** The script fails with an `IndexError: list index out of range` because the index calculation `9 - step + 1` evaluates to `10` when `step` is `0`, which is out of bounds for the 10-element list `tbl`.

**Hint:** Wrong index position / off-by-one.
