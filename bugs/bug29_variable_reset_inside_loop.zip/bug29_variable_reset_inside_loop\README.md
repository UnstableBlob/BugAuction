**Error:** The script fails because the accumulator `acc` is reset to `0` at the beginning of every iteration of the loop, resulting in a hash that only reflects the very last step of the computation.

**Hint:** Variable reset inside loop.
