#include <stdio.h>
#include <stdint.h>

static const uint64_t M1 = 0x9E3779B97F4A7C15ULL;
static const uint64_t M2 = 0xBF58476D1CE4E5B9ULL;
static const uint64_t MASK = 0xFFFFFFFFFFFFFFFFULL;

/* Bug 115: "not v % 2 == 0" means !(v) % 2 == 0 which is same as v%2==0 (since !v is 0 or 1) 
   In C: !v % 2 == 0  =>  (!v) % 2 == 0.  When v!=0, !v=0, 0%2==0 -> always true for v>0.
   The correct form is !(v % 2 == 0) i.e. v%2 != 0.
   We'll make the buggy version use !(v) % 2 == 0 which is always true for v>0. */
int main(void) {
    /* BUG: !v % 2 == 0  always evaluates based on !v, not !(v%2==0) */
    uint64_t acc = 0x2468ACE013579BDFULL;
    for (int i = 0; i < 10; i++) {
        int v = i + 1;
        /* !v evaluates to 0 for any v>0; so (!v)%2==0 is 0%2==0 which is 1 (true). Always true. */
        if (!v % 2 == 0) {   /* BUG: always true when v>0 */
            acc ^= (uint64_t)v * M1;
        } else {
            acc += (uint64_t)v * M2;
        }
        acc &= MASK;
        int sh = i % 11 + 1;
        acc = ((acc << sh) | (acc >> (64 - sh))) & MASK;
    }

    uint64_t correct = 0x2468ACE013579BDFULL;
    for (int i = 0; i < 10; i++) {
        int v = i + 1;
        if (!(v % 2 == 0)) {   /* CORRECT: v is odd */
            correct ^= (uint64_t)v * M1;
        } else {
            correct += (uint64_t)v * M2;
        }
        correct &= MASK;
        int sh = i % 11 + 1;
        correct = ((correct << sh) | (correct >> (64 - sh))) & MASK;
    }

    if (acc == correct) { fprintf(stderr, "AssertionError: misplaced not same result as correct not\n"); return 1; }
    fprintf(stderr, "ValueError: not applied to v before %%: got 0x%llx expected 0x%llx\n",
            (unsigned long long)acc, (unsigned long long)correct);
    return 1;
}
