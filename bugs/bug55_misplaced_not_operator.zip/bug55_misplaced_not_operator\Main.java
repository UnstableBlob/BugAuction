import java.util.Base64;
import java.nio.ByteBuffer;

public class Main {
    static final long M1 = 0x9E3779B97F4A7C15L;
    static final long M2 = 0xBF58476D1CE4E5B9L;

    public static void main(String[] args) {
        /* BUG: !v % 2 == 0 in Java: since !v is not valid for int,
           we simulate "not v % 2 == 0" as (v == 0) % 2 == 0 doesn't apply cleanly.
           In Java we simulate it as: (v != 0 ? 0 : 1) % 2 == 0, i.e. !v is boolean.
           Actually in Java, the Python bug "not v % 2 == 0" applies ! to v first
           (v is never 0 in range 1-10, so !v = false → false % 2 == 0 → buggy).
           We simulate this: boolToInt(!bool(v)) % 2 == 0.
           When v>0: bool(v)=true, !bool(v)=false=0, 0%2==0 → always true. */
        long acc = 0x2468ACE013579BDFL;
        for (int i = 0; i < 10; i++) {
            int v = i + 1;
            // Simulate: !(boolean cast of v) % 2 == 0 → always 0%2==0 → always true for v>0
            int notV = (v != 0) ? 0 : 1;  // !v (integer)
            if (notV % 2 == 0) {   // BUG: always true
                acc ^= (long)v * M1;
            } else {
                acc += (long)v * M2;
            }
            acc &= 0xFFFFFFFFFFFFFFFFL;
            int sh = i % 11 + 1;
            acc = (acc << sh) | (acc >>> (64 - sh));
        }

        long correct = 0x2468ACE013579BDFL;
        for (int i = 0; i < 10; i++) {
            int v = i + 1;
            if (!(v % 2 == 0)) {   // CORRECT: v is odd
                correct ^= (long)v * M1;
            } else {
                correct += (long)v * M2;
            }
            correct &= 0xFFFFFFFFFFFFFFFFL;
            int sh = i % 11 + 1;
            correct = (correct << sh) | (correct >>> (64 - sh));
        }

        if (acc == correct) {
            System.err.println("AssertionError: misplaced not same result as correct not"); System.exit(1);
        }
        System.err.printf("ValueError: not applied to v before %%: got 0x%x expected 0x%x%n", acc, correct);
        System.exit(1);
    }
}
