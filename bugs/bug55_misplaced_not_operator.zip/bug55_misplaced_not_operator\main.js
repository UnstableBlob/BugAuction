// BUG: !v % 2 === 0 — !v is Boolean(false) when v>0; Number(false)=0; 0%2===0 always true
const M1 = 0x9E3779B9n * (2n**32n) + 0x7F4A7C15n;
const M2 = 0xBF58476Dn * (2n**32n) + 0x1CE4E5B9n;
const MASK = 0xFFFFFFFFFFFFFFFFn;

let acc = 0x2468ACE013579BDFn;
for (let i = 0; i < 10; i++) {
    const v = i + 1;
    // BUG: !v % 2 === 0 → (!v) % 2 === 0 → (false) % 2 === 0 → 0 % 2 === 0 → always true when v>0
    if (!v % 2 === 0) {
        acc ^= BigInt(v) * M1; acc &= MASK;
    } else {
        acc += BigInt(v) * M2; acc &= MASK;
    }
    const sh = BigInt(i % 11 + 1);
    acc = ((acc << sh) | (acc >> (64n - sh))) & MASK;
}

let correct = 0x2468ACE013579BDFn;
for (let i = 0; i < 10; i++) {
    const v = i + 1;
    if (!(v % 2 === 0)) {   // CORRECT
        correct ^= BigInt(v) * M1; correct &= MASK;
    } else {
        correct += BigInt(v) * M2; correct &= MASK;
    }
    const sh = BigInt(i % 11 + 1);
    correct = ((correct << sh) | (correct >> (64n - sh))) & MASK;
}

if (acc === correct) {
    process.stderr.write("AssertionError: misplaced not same result as correct not\n"); process.exit(1);
}
process.stderr.write(`ValueError: not applied to v before %: got 0x${acc.toString(16)} expected 0x${correct.toString(16)}\n`);
process.exit(1);
