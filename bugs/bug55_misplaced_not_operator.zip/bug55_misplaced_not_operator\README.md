**Error:** Not applied to v before %.

**Hint:** Misplaced not operator.
