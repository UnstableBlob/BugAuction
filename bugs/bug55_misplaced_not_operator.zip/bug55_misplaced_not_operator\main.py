import base64, struct

def run():
    data = list(range(1, 11))
    acc = 0x2468ACE013579BDF
    for i, v in enumerate(data):
        if not v % 2 == 0:
            acc ^= v * 0x9E3779B97F4A7C15
        else:
            acc += v * 0xBF58476D1CE4E5B9
        acc &= 0xFFFFFFFFFFFFFFFF
        acc = ((acc << (i % 11 + 1)) | (acc >> (63 - i % 11))) & 0xFFFFFFFFFFFFFFFF
    correct = 0x2468ACE013579BDF
    for i, v in enumerate(data):
        if not (v % 2 == 0):
            correct ^= v * 0x9E3779B97F4A7C15
        else:
            correct += v * 0xBF58476D1CE4E5B9
        correct &= 0xFFFFFFFFFFFFFFFF
        correct = ((correct << (i % 11 + 1)) | (correct >> (63 - i % 11))) & 0xFFFFFFFFFFFFFFFF
    if acc == correct:
        raise AssertionError("misplaced not same result as correct not")
    raise ValueError(f"not applied to v before %: got {acc:#x} expected {correct:#x}")

run()
