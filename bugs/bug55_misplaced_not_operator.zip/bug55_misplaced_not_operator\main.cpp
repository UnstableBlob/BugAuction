#include <iostream>
#include <cstdint>

static const uint64_t M1 = 0x9E3779B97F4A7C15ULL;
static const uint64_t M2 = 0xBF58476D1CE4E5B9ULL;
static const uint64_t MASK = 0xFFFFFFFFFFFFFFFFULL;

int main() {
    /* BUG: !v % 2 == 0 — always true for v>0 */
    uint64_t acc = 0x2468ACE013579BDFULL;
    for (int i = 0; i < 10; i++) {
        int v = i + 1;
        if (!v % 2 == 0) {
            acc ^= (uint64_t)v * M1;
        } else {
            acc += (uint64_t)v * M2;
        }
        acc &= MASK;
        int sh = i % 11 + 1;
        acc = ((acc << sh) | (acc >> (64 - sh))) & MASK;
    }

    uint64_t correct = 0x2468ACE013579BDFULL;
    for (int i = 0; i < 10; i++) {
        int v = i + 1;
        if (!(v % 2 == 0)) {
            correct ^= (uint64_t)v * M1;
        } else {
            correct += (uint64_t)v * M2;
        }
        correct &= MASK;
        int sh = i % 11 + 1;
        correct = ((correct << sh) | (correct >> (64 - sh))) & MASK;
    }

    if (acc == correct) { std::cerr << "AssertionError: misplaced not same result as correct not" << std::endl; return 1; }
    std::cerr << "ValueError: not applied to v before %: got 0x" << std::hex << acc << " expected 0x" << correct << std::endl;
    return 1;
}
