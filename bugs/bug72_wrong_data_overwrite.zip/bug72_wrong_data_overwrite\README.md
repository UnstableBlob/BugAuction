**Error:** Second pass XORed with backup (original) instead of staying as-is.

**Hint:** Wrong data overwrite.
