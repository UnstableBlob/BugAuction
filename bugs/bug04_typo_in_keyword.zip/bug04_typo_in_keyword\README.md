**Error:** The script fails with a `SyntaxError: invalid syntax` because of a typo in the `return` keyword, which is written as `retrun`.

**Hint:** Syntax error.
