**Error:** The recursive function lacks a base case, causing it to recurse infinitely until it hits the maximum recursion depth, resulting in a `RecursionError`.

**Hint:** Missing base case.
