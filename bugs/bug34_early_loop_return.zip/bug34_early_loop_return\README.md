**Error:** The `compute` function returns the result after the very first iteration of the loop, which means it only processes the first seed in the list and ignores all subsequent values.

**Hint:** Early return inside loop.
