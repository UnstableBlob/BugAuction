**Error:** The script fails with a `SyntaxError: invalid syntax` because the function definition is missing a colon at the end.

**Hint:** Syntax error.
