**Error:** Triple negation flipped logic.

**Hint:** Double negation error.
