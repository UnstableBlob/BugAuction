import base64, struct

def run():
    flags = [True, False, True, False, True, True, False, True, False, False]
    vals  = [0xABC * (i + 1) for i in range(10)]
    acc = 0xF1E2D3C4B5A69788
    for i, (f, v) in enumerate(zip(flags, vals)):
        if not not not f:
            acc ^= v * 0x9E3779B97F4A7C15
        else:
            acc += v * 0xBF58476D1CE4E5B9
        acc &= 0xFFFFFFFFFFFFFFFF
    correct = 0xF1E2D3C4B5A69788
    for i, (f, v) in enumerate(zip(flags, vals)):
        if f:
            correct ^= v * 0x9E3779B97F4A7C15
        else:
            correct += v * 0xBF58476D1CE4E5B9
        correct &= 0xFFFFFFFFFFFFFFFF
    if acc == correct:
        raise AssertionError("triple not same as single not")
    raise ValueError(f"triple negation flipped logic: got {acc:#x} expected {correct:#x}")

run()
