import java.util.Base64;
import java.nio.ByteBuffer;

public class Main {
    static final long M1 = 0x9E3779B97F4A7C15L;
    static final long M2 = 0xBF58476D1CE4E5B9L;

    public static void main(String[] args) {
        boolean[] flags = {true,false,true,false,true,true,false,true,false,false};
        long[] vals = new long[10];
        for (int i = 0; i < 10; i++) vals[i] = (long)(0xABC * (i+1));

        /* BUG: !!!f (triple NOT in Java via chaining) = !f — logic inverted */
        long acc = 0xF1E2D3C4B5A69788L;
        for (int i = 0; i < 10; i++) {
            boolean f = flags[i]; long v = vals[i];
            if (!!!f) {   // BUG: triple NOT = single NOT
                acc ^= v * M1;
            } else {
                acc += v * M2;
            }
            acc &= 0xFFFFFFFFFFFFFFFFL;
        }

        long correct = 0xF1E2D3C4B5A69788L;
        for (int i = 0; i < 10; i++) {
            boolean f = flags[i]; long v = vals[i];
            if (f) {
                correct ^= v * M1;
            } else {
                correct += v * M2;
            }
            correct &= 0xFFFFFFFFFFFFFFFFL;
        }

        if (acc == correct) {
            System.err.println("AssertionError: triple not same as single not"); System.exit(1);
        }
        System.err.printf("ValueError: triple negation flipped logic: got 0x%x expected 0x%x%n", acc, correct);
        System.exit(1);
    }
}
