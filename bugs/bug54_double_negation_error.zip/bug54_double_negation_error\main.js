// BUG: !!!f (triple NOT) = !f — logic inverted
const M1 = 0x9E3779B9n * (2n**32n) + 0x7F4A7C15n;
const M2 = 0xBF58476Dn * (2n**32n) + 0x1CE4E5B9n;
const MASK = 0xFFFFFFFFFFFFFFFFn;

const flags = [true,false,true,false,true,true,false,true,false,false];
const vals = Array.from({length:10}, (_,i) => BigInt(0xABC * (i+1)));

let acc = 0xF1E2D3C4B5A69788n;
for (let i = 0; i < 10; i++) {
    const f = flags[i], v = vals[i];
    if (!!!f) {   // BUG: !!! = !
        acc ^= v * M1; acc &= MASK;
    } else {
        acc += v * M2; acc &= MASK;
    }
}

let correct = 0xF1E2D3C4B5A69788n;
for (let i = 0; i < 10; i++) {
    const f = flags[i], v = vals[i];
    if (f) {
        correct ^= v * M1; correct &= MASK;
    } else {
        correct += v * M2; correct &= MASK;
    }
}

if (acc === correct) {
    process.stderr.write("AssertionError: triple not same as single not\n"); process.exit(1);
}
process.stderr.write(`ValueError: triple negation flipped logic: got 0x${acc.toString(16)} expected 0x${correct.toString(16)}\n`);
process.exit(1);
