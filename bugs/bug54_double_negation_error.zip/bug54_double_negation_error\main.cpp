#include <iostream>
#include <cstdint>

static const uint64_t M1 = 0x9E3779B97F4A7C15ULL;
static const uint64_t M2 = 0xBF58476D1CE4E5B9ULL;
static const uint64_t MASK = 0xFFFFFFFFFFFFFFFFULL;

int main() {
    bool flags[] = {true,false,true,false,true,true,false,true,false,false};
    uint64_t vals[10];
    for (int i = 0; i < 10; i++) vals[i] = (uint64_t)(0xABC * (i+1));

    /* BUG: !!!f  (triple NOT) = !f — logic inverted */
    uint64_t acc = 0xF1E2D3C4B5A69788ULL;
    for (int i = 0; i < 10; i++) {
        bool f = flags[i]; uint64_t v = vals[i];
        if (!!!f) {
            acc ^= v * M1;
        } else {
            acc += v * M2;
        }
        acc &= MASK;
    }

    uint64_t correct = 0xF1E2D3C4B5A69788ULL;
    for (int i = 0; i < 10; i++) {
        bool f = flags[i]; uint64_t v = vals[i];
        if (f) {
            correct ^= v * M1;
        } else {
            correct += v * M2;
        }
        correct &= MASK;
    }

    if (acc == correct) { std::cerr << "AssertionError: triple not same as single not" << std::endl; return 1; }
    std::cerr << "ValueError: triple negation flipped logic: got 0x" << std::hex << acc << " expected 0x" << correct << std::endl;
    return 1;
}
