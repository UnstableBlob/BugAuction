**Error:** Step is 3 instead of 2.

**Hint:** Wrong iteration step.
