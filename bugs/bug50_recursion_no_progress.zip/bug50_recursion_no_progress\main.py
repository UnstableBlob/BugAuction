import base64, struct
import sys
sys.setrecursionlimit(50)

def descent(n, acc):
    if n <= 0:
        return acc
    acc = (acc ^ n * 0xBF58476D1CE4E5B9) & 0xFFFFFFFFFFFFFFFF
    return descent(n, acc)

result = descent(10, 0x0A0B0C0D0E0F1011)
raw = struct.pack(">Q", result)
print(base64.b64encode(raw).decode())
