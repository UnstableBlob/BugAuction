#include <stdio.h>
#include <stdint.h>

static const uint64_t MAGIC = 0xBF58476D1CE4E5B9ULL;

/* BUG: descent(n, acc) called without decrementing n -> infinite recursion */
uint64_t descent(int n, uint64_t acc) {
    if (n <= 0) return acc;
    acc = (acc ^ (uint64_t)n * MAGIC);
    return descent(n, acc);  /* BUG: should be descent(n-1, acc) */
}

int main(void) {
    uint64_t result = descent(10, 0x0A0B0C0D0E0F1011ULL);
    fprintf(stderr, "Error: expected stack overflow but got result 0x%llx\n",
            (unsigned long long)result);
    return 1;
}
