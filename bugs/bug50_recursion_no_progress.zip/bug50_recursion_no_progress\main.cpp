#include <iostream>
#include <cstdint>

static const uint64_t MAGIC = 0xBF58476D1CE4E5B9ULL;

/* BUG: no progress - passes n instead of n-1 */
uint64_t descent(int n, uint64_t acc) {
    if (n <= 0) return acc;
    acc = (acc ^ (uint64_t)n * MAGIC);
    return descent(n, acc);  // BUG
}

int main() {
    uint64_t result = descent(10, 0x0A0B0C0D0E0F1011ULL);
    std::cerr << "Error: expected stack overflow but got result 0x" << std::hex << result << std::endl;
    return 1;
}
