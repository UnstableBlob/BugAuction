// BUG: recursion never makes progress - passes n unchanged
const MAGIC = 0xBF58476Dn * (2n**32n) + 0x1CE4E5B9n;
const MASK = 0xFFFFFFFFFFFFFFFFn;

function descent(n, acc) {
    if (n <= 0n) return acc;
    acc = (acc ^ (n * MAGIC)) & MASK;
    return descent(n, acc);  // BUG: should be descent(n - 1n, acc)
}

try {
    const result = descent(10n, 0x0A0B0C0Dn * (2n**32n) + 0x0E0F1011n);
    process.stderr.write(`Error: expected stack overflow but got result 0x${result.toString(16)}\n`);
} catch (e) {
    process.stderr.write(`${e.constructor.name}: ${e.message}\n`);
}
process.exit(1);
