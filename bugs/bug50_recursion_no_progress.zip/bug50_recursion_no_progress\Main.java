import java.util.Base64;
import java.nio.ByteBuffer;

public class Main {
    static final long MAGIC = 0xBF58476D1CE4E5B9L;

    /* BUG: no progress - passes n instead of n-1 */
    static long descent(int n, long acc) {
        if (n <= 0) return acc;
        acc = (acc ^ (long)n * MAGIC);
        return descent(n, acc);  // BUG: infinite recursion
    }

    public static void main(String[] args) {
        try {
            long result = descent(10, 0x0A0B0C0D0E0F1011L);
            System.err.println("Error: expected StackOverflowError but got result 0x" + Long.toHexString(result));
        } catch (StackOverflowError e) {
            System.err.println("StackOverflowError: recursion makes no progress (n not decremented)");
        }
        System.exit(1);
    }
}
