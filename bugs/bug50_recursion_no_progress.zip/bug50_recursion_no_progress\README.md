**Error:** The script fails due to an error in the implementation.

**Hint:** Recursion no progress.
