**Error:** The script fails due to an error in the implementation.

**Hint:** Missing edge case check.
