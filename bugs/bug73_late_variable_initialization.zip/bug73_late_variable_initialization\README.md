**Error:** The script fails due to an error in the implementation.

**Hint:** Late variable initialization.
