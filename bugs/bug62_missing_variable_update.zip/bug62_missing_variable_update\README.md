**Error:** Second window slot never updated.

**Hint:** Missing variable update.
