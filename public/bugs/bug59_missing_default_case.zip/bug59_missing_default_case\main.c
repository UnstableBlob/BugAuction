#include <stdio.h>
#include <stdlib.h>

unsigned long long tag(unsigned long long v) {
    if (v == 1) return 0xAAAA;
    else if (v == 2) return 0xBBBB;
    else if (v == 3) return 0xCCCC;
    fprintf(stderr, "TypeError: unsupported operand type(s) for *: 'NoneType' and 'int'\n");
    exit(1);
}

int main() {
    unsigned long long data[] = {1, 2, 3, 4, 1, 3, 2, 4, 1, 2};
    unsigned long long acc = 0x123456789ABCDEF0ULL;
    for (int i = 0; i < 10; i++) {
        unsigned long long t = tag(data[i]);
        acc ^= t * (i + 1);
        acc = (acc * 0x9E3779B97F4A7C15ULL);
    }
    printf("%llu\n", acc);
    return 0;
}
