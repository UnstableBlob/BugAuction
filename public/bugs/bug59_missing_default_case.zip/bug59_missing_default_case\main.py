import base64, struct

def tag(v):
    if v == 1:
        return 0xAAAA
    elif v == 2:
        return 0xBBBB
    elif v == 3:
        return 0xCCCC

def run():
    data = [1, 2, 3, 4, 1, 3, 2, 4, 1, 2]
    acc = 0x123456789ABCDEF0
    for i, v in enumerate(data):
        t = tag(v)
        acc ^= t * (i + 1)
        acc = (acc * 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF
    raw = struct.pack(">Q", acc)
    print(base64.b64encode(raw).decode())

run()
