function tag(v) {
    if (v === 1n) return 0xAAAAn;
    else if (v === 2n) return 0xBBBBn;
    else if (v === 3n) return 0xCCCCn;
    console.error("TypeError: unsupported operand type(s) for *: 'NoneType' and 'int'");
    process.exit(1);
}

function run() {
    let data = [1n, 2n, 3n, 4n, 1n, 3n, 2n, 4n, 1n, 2n];
    let acc = 0x123456789ABCDEF0n;
    for (let i = 0; i < data.length; i++) {
        let t = tag(data[i]);
        acc ^= t * BigInt(i + 1);
        acc = (acc * 0x9E3779B97F4A7C15n) & 0xFFFFFFFFFFFFFFFFn;
    }
    console.log(acc.toString());
}
run();
