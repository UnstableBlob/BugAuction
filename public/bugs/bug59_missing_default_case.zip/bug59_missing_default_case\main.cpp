#include <iostream>
#include <vector>

unsigned long long tag(unsigned long long v) {
    if (v == 1) return 0xAAAA;
    else if (v == 2) return 0xBBBB;
    else if (v == 3) return 0xCCCC;
    std::cerr << "TypeError: unsupported operand type(s) for *: 'NoneType' and 'int'\n";
    exit(1);
}

int main() {
    std::vector<unsigned long long> data = {1, 2, 3, 4, 1, 3, 2, 4, 1, 2};
    unsigned long long acc = 0x123456789ABCDEF0ULL;
    for (size_t i = 0; i < data.size(); i++) {
        unsigned long long t = tag(data[i]);
        acc ^= t * (i + 1);
        acc = (acc * 0x9E3779B97F4A7C15ULL);
    }
    std::cout << acc << "\n";
    return 0;
}
