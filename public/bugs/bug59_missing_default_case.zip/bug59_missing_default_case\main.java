public class main {
    static long tag(long v) {
        if (v == 1) return 0xAAAA;
        else if (v == 2) return 0xBBBB;
        else if (v == 3) return 0xCCCC;
        System.err.println("TypeError: unsupported operand type(s) for *: 'NoneType' and 'int'");
        System.exit(1);
        return 0;
    }

    public static void main(String[] args) {
        long[] data = {1, 2, 3, 4, 1, 3, 2, 4, 1, 2};
        long acc = 0x123456789ABCDEF0L;
        for (int i = 0; i < data.length; i++) {
            long t = tag(data[i]);
            acc ^= t * (i + 1);
            acc = (acc * 0x9E3779B97F4A7C15L);
        }
        System.out.println(acc);
    }
}
