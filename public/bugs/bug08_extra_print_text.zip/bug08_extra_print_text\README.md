**Error:** The script's output includes extra prefix text ("Result: ") which might break automated tests or consumers that expect only the base64 encoded result.

**Hint:** Extra print text.
