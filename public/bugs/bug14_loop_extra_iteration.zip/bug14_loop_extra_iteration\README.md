**Error:** The script fails with an `IndexError: list index out of range` because the `while` loop condition `i <= len(seeds)` allows the index `i` to reach the length of the list, which is one past the valid maximum index.

**Hint:** Loop extra iteration.
