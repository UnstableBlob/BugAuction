**Error:** Accumulator not reset between groups.

**Hint:** Accumulator not reset.
