public class main {
    static long classify(long v) {
        if (v < 50) return 0xAAAA;
        else if (v < 50) return 0xBBBB;
        else if (v < 100) return 0xCCCC;
        else return 0xDDDD;
    }

    public static void main(String[] args) {
        long[] vals = {10, 40, 50, 60, 90, 100, 110, 30, 70, 80};
        long acc = 0x7777888899990000L;
        for (int i = 0; i < vals.length; i++) {
            long c = classify(vals[i]);
            acc ^= c * (i + 1);
            acc = (acc * 0x9E3779B97F4A7C15L);
        }
        
        long correct = 0x7777888899990000L;
        for (int i = 0; i < vals.length; i++) {
            long c;
            if (vals[i] < 50) c = 0xAAAA;
            else if (vals[i] < 75) c = 0xBBBB;
            else if (vals[i] < 100) c = 0xCCCC;
            else c = 0xDDDD;
            correct ^= c * (i + 1);
            correct = (correct * 0x9E3779B97F4A7C15L);
        }
        
        if (acc == correct) {
            System.err.println("AssertionError: duplicate condition same result");
            System.exit(1);
        }
        System.err.printf("ValueError: duplicate elif condition makes 0xBBBB unreachable: got 0x%s expected 0x%s\n", Long.toHexString(acc), Long.toHexString(correct));
        System.exit(1);
    }
}
