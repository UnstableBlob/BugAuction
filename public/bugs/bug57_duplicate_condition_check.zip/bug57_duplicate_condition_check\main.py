import base64, struct

def classify(v):
    if v < 50:
        return 0xAAAA
    elif v < 50:
        return 0xBBBB
    elif v < 100:
        return 0xCCCC
    else:
        return 0xDDDD

def run():
    vals = [10, 40, 50, 60, 90, 100, 110, 30, 70, 80]
    acc = 0x7777888899990000
    for i, v in enumerate(vals):
        c = classify(v)
        acc ^= c * (i + 1)
        acc = (acc * 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF
    correct = 0x7777888899990000
    for i, v in enumerate(vals):
        if v < 50:
            c = 0xAAAA
        elif v < 75:
            c = 0xBBBB
        elif v < 100:
            c = 0xCCCC
        else:
            c = 0xDDDD
        correct ^= c * (i + 1)
        correct = (correct * 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF
    if acc == correct:
        raise AssertionError("duplicate condition same result")
    raise ValueError(f"duplicate elif condition makes 0xBBBB unreachable: got {acc:#x} expected {correct:#x}")

run()
