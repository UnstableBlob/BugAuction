**Error:** Duplicate elif condition makes 0xBBBB unreachable.

**Hint:** Duplicate condition check.
