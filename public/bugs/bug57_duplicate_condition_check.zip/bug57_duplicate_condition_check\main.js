function classify(v) {
    if (v < 50) return 0xAAAAn;
    else if (v < 50) return 0xBBBBn;
    else if (v < 100) return 0xCCCCn;
    else return 0xDDDDn;
}

function run() {
    let vals = [10, 40, 50, 60, 90, 100, 110, 30, 70, 80];
    let acc = 0x7777888899990000n;
    for (let i = 0; i < vals.length; i++) {
        let v = vals[i];
        let c = classify(v);
        acc ^= c * BigInt(i + 1);
        acc = (acc * 0x9E3779B97F4A7C15n) & 0xFFFFFFFFFFFFFFFFn;
    }
    
    let correct = 0x7777888899990000n;
    for (let i = 0; i < vals.length; i++) {
        let v = vals[i];
        let c;
        if (v < 50) c = 0xAAAAn;
        else if (v < 75) c = 0xBBBBn;
        else if (v < 100) c = 0xCCCCn;
        else c = 0xDDDDn;
        correct ^= c * BigInt(i + 1);
        correct = (correct * 0x9E3779B97F4A7C15n) & 0xFFFFFFFFFFFFFFFFn;
    }
    
    if (acc === correct) {
        console.error("AssertionError: duplicate condition same result");
        process.exit(1);
    }
    console.error(`ValueError: duplicate elif condition makes 0xBBBB unreachable: got 0x${acc.toString(16)} expected 0x${correct.toString(16)}`);
    process.exit(1);
}

run();
