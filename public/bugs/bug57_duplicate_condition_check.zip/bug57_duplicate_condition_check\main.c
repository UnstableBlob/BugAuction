#include <stdio.h>
#include <stdlib.h>

unsigned long long classify(unsigned long long v) {
    if (v < 50) return 0xAAAA;
    else if (v < 50) return 0xBBBB;
    else if (v < 100) return 0xCCCC;
    else return 0xDDDD;
}

int main() {
    unsigned long long vals[] = {10, 40, 50, 60, 90, 100, 110, 30, 70, 80};
    unsigned long long acc = 0x7777888899990000ULL;
    for (int i = 0; i < 10; i++) {
        unsigned long long c = classify(vals[i]);
        acc ^= c * (i + 1);
        acc = (acc * 0x9E3779B97F4A7C15ULL);
    }
    
    unsigned long long correct = 0x7777888899990000ULL;
    for (int i = 0; i < 10; i++) {
        unsigned long long c;
        if (vals[i] < 50) c = 0xAAAA;
        else if (vals[i] < 75) c = 0xBBBB;
        else if (vals[i] < 100) c = 0xCCCC;
        else c = 0xDDDD;
        correct ^= c * (i + 1);
        correct = (correct * 0x9E3779B97F4A7C15ULL);
    }
    
    if (acc == correct) {
        fprintf(stderr, "AssertionError: duplicate condition same result\n");
        return 1;
    }
    fprintf(stderr, "ValueError: duplicate elif condition makes 0xBBBB unreachable: got 0x%llx expected 0x%llx\n", acc, correct);
    return 1;
}
