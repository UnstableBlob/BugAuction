**Error:** Reverse loop stops at 1 not 0, skips index 0.

**Hint:** Incorrect reverse loop.
