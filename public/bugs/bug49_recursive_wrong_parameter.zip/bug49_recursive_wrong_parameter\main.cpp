#include <iostream>
#include <cstdint>

static const uint64_t MAGIC = 0x9E3779B97F4A7C15ULL;

/* BUG: recursive call passes n instead of n-1 */
uint64_t fold(int n, uint64_t acc) {
    if (n == 0) return acc;
    acc = (acc ^ (uint64_t)n * MAGIC);
    int shift = n % 7 + 1;
    acc = ((acc << shift) | (acc >> (64 - shift)));
    return fold(n, acc);  // BUG
}

int main() {
    uint64_t result = fold(10, 0xDEADBEEFCAFEBABEULL);
    std::cerr << "Error: expected stack overflow but got result 0x" << std::hex << result << std::endl;
    return 1;
}
