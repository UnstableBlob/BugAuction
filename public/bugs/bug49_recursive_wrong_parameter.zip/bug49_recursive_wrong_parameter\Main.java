import java.util.Base64;
import java.nio.ByteBuffer;

public class Main {
    static final long MAGIC = 0x9E3779B97F4A7C15L;

    /* BUG: recursive call passes n instead of n-1 */
    static long fold(int n, long acc) {
        if (n == 0) return acc;
        acc = (acc ^ (long)n * MAGIC);
        int shift = n % 7 + 1;
        acc = (acc << shift) | (acc >>> (64 - shift));
        return fold(n, acc);  // BUG: infinite recursion
    }

    public static void main(String[] args) {
        // This will throw StackOverflowError
        try {
            long result = fold(10, 0xDEADBEEFCAFEBABEL);
            System.err.println("Error: expected StackOverflowError but got result 0x" + Long.toHexString(result));
        } catch (StackOverflowError e) {
            System.err.println("StackOverflowError: recursive call with wrong parameter causes infinite recursion");
        }
        System.exit(1);
    }
}
