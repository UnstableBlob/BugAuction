// BUG: recursive call passes n instead of n-1 (infinite recursion / stack overflow)
const MAGIC = 0x9E3779B9n * (2n**32n) + 0x7F4A7C15n;
const MASK = 0xFFFFFFFFFFFFFFFFn;

function fold(n, acc) {
    if (n === 0n) return acc;
    acc = (acc ^ (n * MAGIC)) & MASK;
    const shift = Number(n % 7n) + 1;
    acc = ((acc << BigInt(shift)) | (acc >> BigInt(64 - shift))) & MASK;
    return fold(n, acc);  // BUG: should be fold(n - 1n, acc)
}

// Node.js will throw RangeError: Maximum call stack size exceeded
try {
    const result = fold(10n, 0xDEADBEEFn * (2n**32n) + 0xCAFEBABEn);
    process.stderr.write(`Error: expected stack overflow but got result 0x${result.toString(16)}\n`);
} catch (e) {
    process.stderr.write(`${e.constructor.name}: ${e.message}\n`);
}
process.exit(1);
