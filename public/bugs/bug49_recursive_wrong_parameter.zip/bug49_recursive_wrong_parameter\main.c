#include <stdio.h>
#include <stdint.h>

/* Bug 108: recursive call passes wrong parameter (n instead of n-1) */
/* This causes infinite recursion / stack overflow */

static const uint64_t MAGIC = 0x9E3779B97F4A7C15ULL;

uint64_t fold(int n, uint64_t acc) {
    if (n == 0) return acc;
    acc = (acc ^ (uint64_t)n * MAGIC);
    int shift = n % 7 + 1;
    acc = ((acc << shift) | (acc >> (64 - shift)));
    return fold(n, acc);  /* BUG: should be fold(n-1, acc) */
}

int main(void) {
    /* This will crash with stack overflow */
    uint64_t result = fold(10, 0xDEADBEEFCAFEBABEULL);
    fprintf(stderr, "Error: expected stack overflow but got result 0x%llx\n",
            (unsigned long long)result);
    return 1;
}
