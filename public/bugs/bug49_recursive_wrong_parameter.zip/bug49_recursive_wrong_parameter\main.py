import base64, struct
import sys
sys.setrecursionlimit(50)

def fold(n, acc):
    if n == 0:
        return acc
    acc = (acc ^ n * 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF
    acc = ((acc << (n % 7 + 1)) | (acc >> (63 - n % 7))) & 0xFFFFFFFFFFFFFFFF
    return fold(n, acc)

result = fold(10, 0xDEADBEEFCAFEBABE)
raw = struct.pack(">Q", result)
print(base64.b64encode(raw).decode())
