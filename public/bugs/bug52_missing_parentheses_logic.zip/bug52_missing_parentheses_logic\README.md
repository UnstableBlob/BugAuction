**Error:** Missing parentheses changed logic.

**Hint:** Missing parentheses logic.
