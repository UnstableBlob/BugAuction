import java.util.Base64;
import java.nio.ByteBuffer;

public class Main {
    static final long M1 = 0x9E3779B97F4A7C15L;
    static final long M2 = 0xBF58476D1CE4E5B9L;

    public static void main(String[] args) {
        boolean[] flags = {true,false,true,true,false,false,true,false,true,true};
        long[] vals = new long[10];
        for (int i = 0; i < 10; i++) vals[i] = (long)(0x100 * (i+1));

        /* BUG: f || (i > 5 && i < 8) instead of (f || i > 5) && i < 8 */
        long acc = 0x5555AAAA5555AAAAL;
        for (int i = 0; i < 10; i++) {
            boolean f = flags[i]; long v = vals[i];
            if (f || (i > 5 && i < 8)) {
                acc ^= v * M1;
            } else {
                acc += v * M2;
            }
            int sh = i % 9 + 1;
            acc = (acc << sh) | (acc >>> (64 - sh));
        }

        long correct = 0x5555AAAA5555AAAAL;
        for (int i = 0; i < 10; i++) {
            boolean f = flags[i]; long v = vals[i];
            if ((f || i > 5) && i < 8) {
                correct ^= v * M1;
            } else {
                correct += v * M2;
            }
            int sh = i % 9 + 1;
            correct = (correct << sh) | (correct >>> (64 - sh));
        }

        if (acc == correct) {
            System.err.println("AssertionError: missing parens same result");
            System.exit(1);
        }
        System.err.printf("ValueError: missing parentheses changed logic: got 0x%x expected 0x%x%n", acc, correct);
        System.exit(1);
    }
}
