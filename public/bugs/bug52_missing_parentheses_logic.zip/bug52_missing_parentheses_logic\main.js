// BUG: operator precedence - f || (i > 5 && i < 8) instead of (f || i > 5) && i < 8
const M1 = 0x9E3779B9n * (2n**32n) + 0x7F4A7C15n;
const M2 = 0xBF58476Dn * (2n**32n) + 0x1CE4E5B9n;
const MASK = 0xFFFFFFFFFFFFFFFFn;

const flags = [true,false,true,true,false,false,true,false,true,true];
const vals = Array.from({length:10}, (_,i) => BigInt(0x100 * (i+1)));

/* BUG: f || (i > 5 && i < 8) */
let acc = 0x5555AAAA5555AAAAn;
for (let i = 0; i < 10; i++) {
    const f = flags[i], v = vals[i];
    if (f || (i > 5 && i < 8)) {
        acc ^= v * M1;
    } else {
        acc += v * M2;
    }
    acc &= MASK;
    const sh = BigInt(i % 9 + 1);
    acc = ((acc << sh) | (acc >> (64n - sh))) & MASK;
}

let correct = 0x5555AAAA5555AAAAn;
for (let i = 0; i < 10; i++) {
    const f = flags[i], v = vals[i];
    if ((f || i > 5) && i < 8) {
        correct ^= v * M1;
    } else {
        correct += v * M2;
    }
    correct &= MASK;
    const sh = BigInt(i % 9 + 1);
    correct = ((correct << sh) | (correct >> (64n - sh))) & MASK;
}

if (acc === correct) {
    process.stderr.write("AssertionError: missing parens same result\n");
    process.exit(1);
}
process.stderr.write(`ValueError: missing parentheses changed logic: got 0x${acc.toString(16)} expected 0x${correct.toString(16)}\n`);
process.exit(1);
