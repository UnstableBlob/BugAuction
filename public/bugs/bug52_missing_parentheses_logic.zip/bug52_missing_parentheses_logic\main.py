import base64, struct

def run():
    flags = [True, False, True, True, False, False, True, False, True, True]
    vals  = [0x100 * (i + 1) for i in range(10)]
    acc = 0x5555AAAA5555AAAA
    for i, (f, v) in enumerate(zip(flags, vals)):
        if f or i > 5 and i < 8:
            acc ^= v * 0x9E3779B97F4A7C15
        else:
            acc += v * 0xBF58476D1CE4E5B9
        acc &= 0xFFFFFFFFFFFFFFFF
        acc = ((acc << (i % 9 + 1)) | (acc >> (63 - i % 9))) & 0xFFFFFFFFFFFFFFFF
    correct = 0x5555AAAA5555AAAA
    for i, (f, v) in enumerate(zip(flags, vals)):
        if (f or i > 5) and i < 8:
            correct ^= v * 0x9E3779B97F4A7C15
        else:
            correct += v * 0xBF58476D1CE4E5B9
        correct &= 0xFFFFFFFFFFFFFFFF
        correct = ((correct << (i % 9 + 1)) | (correct >> (63 - i % 9))) & 0xFFFFFFFFFFFFFFFF
    if acc == correct:
        raise AssertionError("missing parens same result")
    raise ValueError(f"missing parentheses changed logic: got {acc:#x} expected {correct:#x}")

run()
