#include <iostream>
#include <cstdint>

static const uint64_t M1 = 0x9E3779B97F4A7C15ULL;
static const uint64_t M2 = 0xBF58476D1CE4E5B9ULL;
static const uint64_t MASK = 0xFFFFFFFFFFFFFFFFULL;

int main() {
    bool flags[] = {true,false,true,true,false,false,true,false,true,true};
    uint64_t vals[10];
    for (int i = 0; i < 10; i++) vals[i] = (uint64_t)(0x100 * (i+1));

    /* BUG: f || (i > 5 && i < 8)  instead of (f || i > 5) && i < 8 */
    uint64_t acc = 0x5555AAAA5555AAAAULL;
    for (int i = 0; i < 10; i++) {
        bool f = flags[i]; uint64_t v = vals[i];
        if (f || (i > 5 && i < 8)) {
            acc ^= v * M1;
        } else {
            acc += v * M2;
        }
        acc &= MASK;
        int sh = i % 9 + 1;
        acc = ((acc << sh) | (acc >> (64 - sh))) & MASK;
    }

    uint64_t correct = 0x5555AAAA5555AAAAULL;
    for (int i = 0; i < 10; i++) {
        bool f = flags[i]; uint64_t v = vals[i];
        if ((f || i > 5) && i < 8) {
            correct ^= v * M1;
        } else {
            correct += v * M2;
        }
        correct &= MASK;
        int sh = i % 9 + 1;
        correct = ((correct << sh) | (correct >> (64 - sh))) & MASK;
    }

    if (acc == correct) {
        std::cerr << "AssertionError: missing parens same result" << std::endl;
        return 1;
    }
    std::cerr << "ValueError: missing parentheses changed logic: got 0x"
              << std::hex << acc << " expected 0x" << correct << std::endl;
    return 1;
}
