**Error:** Redundant final assignment reset acc to seed each iteration.

**Hint:** Redundant assignment.
