#include <iostream>
#include <cstdint>

static const uint64_t M1 = 0x9E3779B97F4A7C15ULL;
static const uint64_t M2 = 0xBF58476D1CE4E5B9ULL;
static const uint64_t MASK = 0xFFFFFFFFFFFFFFFFULL;

int main() {
    /* BUG: v>3 && v<7 instead of v>3 || v<7 */
    uint64_t acc = 0xE7E7E7E7E7E7E7E7ULL;
    for (int v = 1; v <= 10; v++) {
        if (v > 3 && v < 7) {
            acc = (acc ^ (uint64_t)v) * M1;
        } else {
            acc = (acc + (uint64_t)v) * M2;
        }
        acc &= MASK;
    }
    uint64_t correct = 0xE7E7E7E7E7E7E7E7ULL;
    for (int v = 1; v <= 10; v++) {
        if (v > 3 || v < 7) {
            correct = (correct ^ (uint64_t)v) * M1;
        } else {
            correct = (correct + (uint64_t)v) * M2;
        }
        correct &= MASK;
    }
    if (acc == correct) { std::cerr << "AssertionError: and or same result" << std::endl; return 1; }
    std::cerr << "ValueError: and used instead of or: got 0x" << std::hex << acc << " expected 0x" << correct << std::endl;
    return 1;
}
