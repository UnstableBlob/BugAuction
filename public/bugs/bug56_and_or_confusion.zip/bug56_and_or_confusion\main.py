import base64, struct

def run():
    data = list(range(1, 11))
    acc = 0xE7E7E7E7E7E7E7E7
    for i, v in enumerate(data):
        if v > 3 and v < 7:
            acc = (acc ^ v) * 0x9E3779B97F4A7C15
        else:
            acc = (acc + v) * 0xBF58476D1CE4E5B9
        acc &= 0xFFFFFFFFFFFFFFFF
    correct = 0xE7E7E7E7E7E7E7E7
    for i, v in enumerate(data):
        if v > 3 or v < 7:
            correct = (correct ^ v) * 0x9E3779B97F4A7C15
        else:
            correct = (correct + v) * 0xBF58476D1CE4E5B9
        correct &= 0xFFFFFFFFFFFFFFFF
    if acc == correct:
        raise AssertionError("and or same result")
    raise ValueError(f"and used instead of or: got {acc:#x} expected {correct:#x}")

run()
