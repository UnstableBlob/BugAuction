#include <stdio.h>
#include <stdint.h>

static const uint64_t M1 = 0x9E3779B97F4A7C15ULL;
static const uint64_t M2 = 0xBF58476D1CE4E5B9ULL;
static const uint64_t MASK = 0xFFFFFFFFFFFFFFFFULL;

int main(void) {
    /* BUG: v>3 && v<7  (AND) instead of v>3 || v<7  (OR, which is always true for 1-10) */
    uint64_t acc = 0xE7E7E7E7E7E7E7E7ULL;
    for (int v = 1; v <= 10; v++) {
        if (v > 3 && v < 7) {   /* BUG: AND — only matches 4,5,6 */
            acc = (acc ^ (uint64_t)v) * M1;
        } else {
            acc = (acc + (uint64_t)v) * M2;
        }
        acc &= MASK;
    }

    uint64_t correct = 0xE7E7E7E7E7E7E7E7ULL;
    for (int v = 1; v <= 10; v++) {
        if (v > 3 || v < 7) {   /* CORRECT: OR — always true (all 1-10 satisfy v<7 or v>3) */
            correct = (correct ^ (uint64_t)v) * M1;
        } else {
            correct = (correct + (uint64_t)v) * M2;
        }
        correct &= MASK;
    }

    if (acc == correct) { fprintf(stderr, "AssertionError: and or same result\n"); return 1; }
    fprintf(stderr, "ValueError: and used instead of or: got 0x%llx expected 0x%llx\n",
            (unsigned long long)acc, (unsigned long long)correct);
    return 1;
}
