import java.util.Base64;
import java.nio.ByteBuffer;

public class Main {
    static final long M1 = 0x9E3779B97F4A7C15L;
    static final long M2 = 0xBF58476D1CE4E5B9L;

    public static void main(String[] args) {
        /* BUG: v>3 && v<7 (AND) instead of v>3 || v<7 (OR) */
        long acc = 0xE7E7E7E7E7E7E7E7L;
        for (int v = 1; v <= 10; v++) {
            if (v > 3 && v < 7) { acc = (acc ^ (long)v) * M1; } else { acc = (acc + (long)v) * M2; }
            acc &= 0xFFFFFFFFFFFFFFFFL;
        }
        long correct = 0xE7E7E7E7E7E7E7E7L;
        for (int v = 1; v <= 10; v++) {
            if (v > 3 || v < 7) { correct = (correct ^ (long)v) * M1; } else { correct = (correct + (long)v) * M2; }
            correct &= 0xFFFFFFFFFFFFFFFFL;
        }
        if (acc == correct) {
            System.err.println("AssertionError: and or same result"); System.exit(1);
        }
        System.err.printf("ValueError: and used instead of or: got 0x%x expected 0x%x%n", acc, correct);
        System.exit(1);
    }
}
