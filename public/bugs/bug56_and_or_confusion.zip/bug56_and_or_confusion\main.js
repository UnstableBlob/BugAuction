// BUG: v>3 && v<7 (AND) instead of v>3 || v<7 (OR)
const M1 = 0x9E3779B9n * (2n**32n) + 0x7F4A7C15n;
const M2 = 0xBF58476Dn * (2n**32n) + 0x1CE4E5B9n;
const MASK = 0xFFFFFFFFFFFFFFFFn;

let acc = 0xE7E7E7E7E7E7E7E7n;
for (let v = 1; v <= 10; v++) {
    if (v > 3 && v < 7) { acc = (acc ^ BigInt(v)) * M1 & MASK; }
    else { acc = (acc + BigInt(v)) * M2 & MASK; }
}
let correct = 0xE7E7E7E7E7E7E7E7n;
for (let v = 1; v <= 10; v++) {
    if (v > 3 || v < 7) { correct = (correct ^ BigInt(v)) * M1 & MASK; }
    else { correct = (correct + BigInt(v)) * M2 & MASK; }
}
if (acc === correct) { process.stderr.write("AssertionError: and or same result\n"); process.exit(1); }
process.stderr.write(`ValueError: and used instead of or: got 0x${acc.toString(16)} expected 0x${correct.toString(16)}\n`);
process.exit(1);
