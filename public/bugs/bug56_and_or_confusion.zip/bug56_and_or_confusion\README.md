**Error:** And used instead of or.

**Hint:** And or confusion.
