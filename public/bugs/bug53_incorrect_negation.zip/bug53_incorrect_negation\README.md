**Error:** Condition incorrectly negated.

**Hint:** Incorrect negation.
