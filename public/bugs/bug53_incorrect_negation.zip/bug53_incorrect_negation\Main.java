import java.util.Base64;
import java.nio.ByteBuffer;

public class Main {
    static final long M1 = 0x9E3779B97F4A7C15L;
    static final long M2 = 0xBF58476D1CE4E5B9L;

    public static void main(String[] args) {
        /* BUG: !(v > 5) — branches are swapped */
        long acc = 0x3C3C3C3C3C3C3C3CL;
        for (int i = 0; i < 10; i++) {
            int v = i + 1;
            if (!(v > 5)) {
                acc = (acc ^ (long)v) * M1;
            } else {
                acc = (acc + (long)v) * M2;
            }
            acc &= 0xFFFFFFFFFFFFFFFFL;
            int sh = i % 7 + 1;
            acc = (acc << sh) | (acc >>> (64 - sh));
        }

        long correct = 0x3C3C3C3C3C3C3C3CL;
        for (int i = 0; i < 10; i++) {
            int v = i + 1;
            if (v > 5) {
                correct = (correct ^ (long)v) * M1;
            } else {
                correct = (correct + (long)v) * M2;
            }
            correct &= 0xFFFFFFFFFFFFFFFFL;
            int sh = i % 7 + 1;
            correct = (correct << sh) | (correct >>> (64 - sh));
        }

        if (acc == correct) {
            System.err.println("AssertionError: negation same result"); System.exit(1);
        }
        System.err.printf("ValueError: condition incorrectly negated: got 0x%x expected 0x%x%n", acc, correct);
        System.exit(1);
    }
}
