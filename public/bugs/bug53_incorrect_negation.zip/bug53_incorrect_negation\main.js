// BUG: !(v > 5) instead of v > 5 — branches are swapped
const M1 = 0x9E3779B9n * (2n**32n) + 0x7F4A7C15n;
const M2 = 0xBF58476Dn * (2n**32n) + 0x1CE4E5B9n;
const MASK = 0xFFFFFFFFFFFFFFFFn;

let acc = 0x3C3C3C3C3C3C3C3Cn;
for (let i = 0; i < 10; i++) {
    const v = i + 1;
    if (!(v > 5)) {   // BUG
        acc = (acc ^ BigInt(v)) * M1 & MASK;
    } else {
        acc = (acc + BigInt(v)) * M2 & MASK;
    }
    const sh = BigInt(i % 7 + 1);
    acc = ((acc << sh) | (acc >> (64n - sh))) & MASK;
}

let correct = 0x3C3C3C3C3C3C3C3Cn;
for (let i = 0; i < 10; i++) {
    const v = i + 1;
    if (v > 5) {
        correct = (correct ^ BigInt(v)) * M1 & MASK;
    } else {
        correct = (correct + BigInt(v)) * M2 & MASK;
    }
    const sh = BigInt(i % 7 + 1);
    correct = ((correct << sh) | (correct >> (64n - sh))) & MASK;
}

if (acc === correct) {
    process.stderr.write("AssertionError: negation same result\n"); process.exit(1);
}
process.stderr.write(`ValueError: condition incorrectly negated: got 0x${acc.toString(16)} expected 0x${correct.toString(16)}\n`);
process.exit(1);
