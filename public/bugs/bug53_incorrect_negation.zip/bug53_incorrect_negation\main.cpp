#include <iostream>
#include <cstdint>

static const uint64_t M1 = 0x9E3779B97F4A7C15ULL;
static const uint64_t M2 = 0xBF58476D1CE4E5B9ULL;
static const uint64_t MASK = 0xFFFFFFFFFFFFFFFFULL;

int main() {
    /* BUG: !(v > 5) — branches are swapped */
    uint64_t acc = 0x3C3C3C3C3C3C3C3CULL;
    for (int i = 0; i < 10; i++) {
        int v = i + 1;
        if (!(v > 5)) {
            acc = (acc ^ (uint64_t)v) * M1;
        } else {
            acc = (acc + (uint64_t)v) * M2;
        }
        acc &= MASK;
        int sh = i % 7 + 1;
        acc = ((acc << sh) | (acc >> (64 - sh))) & MASK;
    }

    uint64_t correct = 0x3C3C3C3C3C3C3C3CULL;
    for (int i = 0; i < 10; i++) {
        int v = i + 1;
        if (v > 5) {
            correct = (correct ^ (uint64_t)v) * M1;
        } else {
            correct = (correct + (uint64_t)v) * M2;
        }
        correct &= MASK;
        int sh = i % 7 + 1;
        correct = ((correct << sh) | (correct >> (64 - sh))) & MASK;
    }

    if (acc == correct) { std::cerr << "AssertionError: negation same result" << std::endl; return 1; }
    std::cerr << "ValueError: condition incorrectly negated: got 0x" << std::hex << acc << " expected 0x" << correct << std::endl;
    return 1;
}
