import base64, struct

def run():
    data = list(range(1, 11))
    acc = 0x3C3C3C3C3C3C3C3C
    for i, v in enumerate(data):
        if not v > 5:
            acc = (acc ^ v) * 0x9E3779B97F4A7C15
        else:
            acc = (acc + v) * 0xBF58476D1CE4E5B9
        acc &= 0xFFFFFFFFFFFFFFFF
        acc = ((acc << (i % 7 + 1)) | (acc >> (63 - i % 7))) & 0xFFFFFFFFFFFFFFFF
    correct = 0x3C3C3C3C3C3C3C3C
    for i, v in enumerate(data):
        if v > 5:
            correct = (correct ^ v) * 0x9E3779B97F4A7C15
        else:
            correct = (correct + v) * 0xBF58476D1CE4E5B9
        correct &= 0xFFFFFFFFFFFFFFFF
        correct = ((correct << (i % 7 + 1)) | (correct >> (63 - i % 7))) & 0xFFFFFFFFFFFFFFFF
    if acc == correct:
        raise AssertionError("negation same result")
    raise ValueError(f"condition incorrectly negated: got {acc:#x} expected {correct:#x}")

run()
