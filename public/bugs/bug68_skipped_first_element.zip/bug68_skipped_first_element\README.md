**Error:** First element skipped (range starts at 1).

**Hint:** Skipped first element.
