**Error:** The loop exits prematurely due to an incorrect conditional check, resulting in an incomplete cryptographic transformation and incorrect final output.

**Hint:** Early exit.
