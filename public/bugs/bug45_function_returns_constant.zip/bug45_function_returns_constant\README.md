**Error:** Function returns constant instead of result.

**Hint:** Function returns constant.
