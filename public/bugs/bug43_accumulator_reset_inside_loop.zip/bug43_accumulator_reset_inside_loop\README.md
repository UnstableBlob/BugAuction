**Error:** Total reset each iteration.

**Hint:** Accumulator reset inside loop.
