**Error:** The script prints the wrong result because it packs and encodes the `checksum0` variable instead of the `final` variable that contains the combined result.

**Hint:** Wrong variable printed.
