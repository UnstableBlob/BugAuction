import base64, struct

def encode(data, key, rounds):
    acc = data ^ key
    for r in range(rounds):
        acc = (acc * 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF
        acc ^= r * key
        acc &= 0xFFFFFFFFFFFFFFFF
        acc = ((acc << (r % 11 + 1)) | (acc >> (63 - r % 11))) & 0xFFFFFFFFFFFFFFFF
    return acc

data   = 0xCAFEBABE12345678
key    = 0xDEADBEEF00000ABC
rounds = 10

result  = encode(key, data, rounds)
correct = encode(data, key, rounds)
if result == correct:
    raise AssertionError("swapped args same result")
raise ValueError(f"data and key arguments swapped: got {result:#x} expected {correct:#x}")
