#include <iostream>
#include <cstdint>

static const uint64_t MAGIC = 0x9E3779B97F4A7C15ULL;

uint64_t encode(uint64_t data, uint64_t key, int rounds) {
    uint64_t acc = data ^ key;
    for (int r = 0; r < rounds; r++) {
        acc = acc * MAGIC;
        acc ^= (uint64_t)r * key;
        int shift = r % 11 + 1;
        acc = ((acc << shift) | (acc >> (64 - shift)));
    }
    return acc;
}

int main() {
    uint64_t data   = 0xCAFEBABE12345678ULL;
    uint64_t key    = 0xDEADBEEF00000ABCULL;
    int      rounds = 10;

    /* BUG: data and key arguments are swapped */
    uint64_t result  = encode(key, data, rounds);
    uint64_t correct = encode(data, key, rounds);

    if (result == correct) {
        std::cerr << "AssertionError: swapped args same result" << std::endl;
        return 1;
    }
    std::cerr << "ValueError: data and key arguments swapped: got 0x"
              << std::hex << result << " expected 0x" << correct << std::endl;
    return 1;
}
