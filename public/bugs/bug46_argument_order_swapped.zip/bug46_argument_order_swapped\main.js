// BUG: data and key arguments are swapped
const MAGIC = 0x9E3779B9n * (2n**32n) + 0x7F4A7C15n;
const MASK = 0xFFFFFFFFFFFFFFFFn;

function encode(data, key, rounds) {
    let acc = data ^ key;
    for (let r = 0n; r < BigInt(rounds); r++) {
        acc = (acc * MAGIC) & MASK;
        acc ^= r * key;
        acc &= MASK;
        const shift = Number(r % 11n) + 1;
        acc = ((acc << BigInt(shift)) | (acc >> BigInt(64 - shift))) & MASK;
    }
    return acc;
}

const data   = 0xCAFEBABEn * (2n**32n) + 0x12345678n;
const key    = 0xDEADBEEFn * (2n**32n) + 0x00000ABCn;
const rounds = 10;

/* BUG: data and key are swapped */
const result  = encode(key, data, rounds);
const correct = encode(data, key, rounds);

if (result === correct) {
    process.stderr.write("AssertionError: swapped args same result\n");
    process.exit(1);
}
process.stderr.write(`ValueError: data and key arguments swapped: got 0x${result.toString(16)} expected 0x${correct.toString(16)}\n`);
process.exit(1);
