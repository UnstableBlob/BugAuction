import java.util.Base64;
import java.nio.ByteBuffer;

public class Main {
    static final long MAGIC = 0x9E3779B97F4A7C15L;

    static long encode(long data, long key, int rounds) {
        long acc = data ^ key;
        for (int r = 0; r < rounds; r++) {
            acc = acc * MAGIC;
            acc ^= (long)r * key;
            int shift = r % 11 + 1;
            acc = (acc << shift) | (acc >>> (64 - shift));
        }
        return acc;
    }

    public static void main(String[] args) {
        long data   = 0xCAFEBABE12345678L;
        long key    = 0xDEADBEEF00000ABCL;
        int  rounds = 10;

        /* BUG: data and key arguments are swapped */
        long result  = encode(key, data, rounds);
        long correct = encode(data, key, rounds);

        if (result == correct) {
            System.err.println("AssertionError: swapped args same result");
            System.exit(1);
        }
        System.err.printf("ValueError: data and key arguments swapped: got 0x%x expected 0x%x%n", result, correct);
        System.exit(1);
    }
}
