#include <stdio.h>
#include <stdint.h>

static const uint64_t MAGIC = 0x9E3779B97F4A7C15ULL;

uint64_t encode(uint64_t data, uint64_t key, int rounds) {
    uint64_t acc = data ^ key;
    for (int r = 0; r < rounds; r++) {
        acc = acc * MAGIC;
        acc ^= (uint64_t)r * key;
        int shift = r % 11 + 1;
        acc = ((acc << shift) | (acc >> (64 - shift)));
    }
    return acc;
}

int main(void) {
    uint64_t data   = 0xCAFEBABE12345678ULL;
    uint64_t key    = 0xDEADBEEF00000ABCULL;
    int      rounds = 10;

    /* BUG: data and key arguments are swapped */
    uint64_t result  = encode(key, data, rounds);
    uint64_t correct = encode(data, key, rounds);

    if (result == correct) {
        fprintf(stderr, "AssertionError: swapped args same result\n");
        return 1;
    }
    fprintf(stderr, "ValueError: data and key arguments swapped: got 0x%llx expected 0x%llx\n",
            (unsigned long long)result, (unsigned long long)correct);
    return 1;
}
