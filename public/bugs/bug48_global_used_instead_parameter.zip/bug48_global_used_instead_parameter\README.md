**Error:** GLOBAL_KEY used instead of key parameter.

**Hint:** Global used instead parameter.
