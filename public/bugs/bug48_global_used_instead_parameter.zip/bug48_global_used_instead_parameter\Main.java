import java.util.Base64;
import java.nio.ByteBuffer;

public class Main {
    static final long GLOBAL_KEY = 0x1111111111111111L;
    static final long MAGIC = 0x9E3779B97F4A7C15L;

    /* BUG: uses GLOBAL_KEY instead of key parameter */
    static long mix(long data, long key) {
        long acc = data;
        for (int i = 0; i < 10; i++) {
            acc ^= GLOBAL_KEY * (long)i;
            acc = acc * MAGIC;
            int shift = i % 7 + 1;
            acc = (acc << shift) | (acc >>> (64 - shift));
        }
        return acc;
    }

    static long mixCorrect(long data, long key) {
        long acc = data;
        for (int i = 0; i < 10; i++) {
            acc ^= key * (long)i;
            acc = acc * MAGIC;
            int shift = i % 7 + 1;
            acc = (acc << shift) | (acc >>> (64 - shift));
        }
        return acc;
    }

    public static void main(String[] args) {
        long data = 0xFEDCBA9876543210L;
        long key  = 0xAAAABBBBCCCCDDDDL;

        long result  = mix(data, key);
        long correct = mixCorrect(data, key);

        if (result == correct) {
            System.err.println("AssertionError: global key equals local key");
            System.exit(1);
        }
        System.err.printf("ValueError: GLOBAL_KEY used instead of key parameter: got 0x%x expected 0x%x%n", result, correct);
        System.exit(1);
    }
}
