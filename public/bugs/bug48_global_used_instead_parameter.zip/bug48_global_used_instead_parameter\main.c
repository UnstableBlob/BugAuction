#include <stdio.h>
#include <stdint.h>

static const uint64_t GLOBAL_KEY = 0x1111111111111111ULL;
static const uint64_t MAGIC = 0x9E3779B97F4A7C15ULL;

/* BUG: uses GLOBAL_KEY instead of the key parameter */
uint64_t mix_bug(uint64_t data, uint64_t key) {
    uint64_t acc = data;
    for (int i = 0; i < 10; i++) {
        acc ^= GLOBAL_KEY * (uint64_t)i;
        acc = acc * MAGIC;
        int shift = i % 7 + 1;
        acc = ((acc << shift) | (acc >> (64 - shift)));
    }
    return acc;
}

/* Correct version for comparison */
uint64_t mix_correct(uint64_t data, uint64_t key) {
    uint64_t acc = data;
    for (int i = 0; i < 10; i++) {
        acc ^= key * (uint64_t)i;
        acc = acc * MAGIC;
        int shift = i % 7 + 1;
        acc = ((acc << shift) | (acc >> (64 - shift)));
    }
    return acc;
}

int main(void) {
    uint64_t data = 0xFEDCBA9876543210ULL;
    uint64_t key  = 0xAAAABBBBCCCCDDDDULL;

    uint64_t result  = mix_bug(data, key);
    uint64_t correct = mix_correct(data, key);

    if (result == correct) {
        fprintf(stderr, "AssertionError: global key equals local key\n");
        return 1;
    }
    fprintf(stderr, "ValueError: GLOBAL_KEY used instead of key parameter: got 0x%llx expected 0x%llx\n",
            (unsigned long long)result, (unsigned long long)correct);
    return 1;
}
