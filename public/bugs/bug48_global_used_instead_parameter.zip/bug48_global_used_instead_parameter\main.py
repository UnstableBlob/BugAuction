import base64, struct

GLOBAL_KEY = 0x1111111111111111

def mix(data, key):
    acc = data
    for i in range(10):
        acc ^= GLOBAL_KEY * i
        acc = (acc * 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF
        acc = ((acc << (i % 7 + 1)) | (acc >> (63 - i % 7))) & 0xFFFFFFFFFFFFFFFF
    return acc

data = 0xFEDCBA9876543210
key  = 0xAAAABBBBCCCCDDDD

result  = mix(data, key)
correct = data
for i in range(10):
    correct ^= key * i
    correct = (correct * 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF
    correct = ((correct << (i % 7 + 1)) | (correct >> (63 - i % 7))) & 0xFFFFFFFFFFFFFFFF

if result == correct:
    raise AssertionError("global key equals local key")
raise ValueError(f"GLOBAL_KEY used instead of key parameter: got {result:#x} expected {correct:#x}")
