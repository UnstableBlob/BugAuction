#include <iostream>
#include <cstdint>

static const uint64_t GLOBAL_KEY = 0x1111111111111111ULL;
static const uint64_t MAGIC = 0x9E3779B97F4A7C15ULL;

/* BUG: uses GLOBAL_KEY instead of key parameter */
uint64_t mix(uint64_t data, uint64_t key) {
    uint64_t acc = data;
    for (int i = 0; i < 10; i++) {
        acc ^= GLOBAL_KEY * (uint64_t)i;
        acc = acc * MAGIC;
        int shift = i % 7 + 1;
        acc = ((acc << shift) | (acc >> (64 - shift)));
    }
    return acc;
}

uint64_t mix_correct(uint64_t data, uint64_t key) {
    uint64_t acc = data;
    for (int i = 0; i < 10; i++) {
        acc ^= key * (uint64_t)i;
        acc = acc * MAGIC;
        int shift = i % 7 + 1;
        acc = ((acc << shift) | (acc >> (64 - shift)));
    }
    return acc;
}

int main() {
    uint64_t data = 0xFEDCBA9876543210ULL;
    uint64_t key  = 0xAAAABBBBCCCCDDDDULL;

    uint64_t result  = mix(data, key);
    uint64_t correct = mix_correct(data, key);

    if (result == correct) {
        std::cerr << "AssertionError: global key equals local key" << std::endl;
        return 1;
    }
    std::cerr << "ValueError: GLOBAL_KEY used instead of key parameter: got 0x"
              << std::hex << result << " expected 0x" << correct << std::endl;
    return 1;
}
