// BUG: uses GLOBAL_KEY instead of key parameter
const GLOBAL_KEY = 0x11111111n * (2n**32n) + 0x11111111n;
const MAGIC = 0x9E3779B9n * (2n**32n) + 0x7F4A7C15n;
const MASK = 0xFFFFFFFFFFFFFFFFn;

/* BUG: uses GLOBAL_KEY instead of key */
function mixBug(data, key) {
    let acc = data;
    for (let i = 0n; i < 10n; i++) {
        acc ^= GLOBAL_KEY * i;
        acc = (acc * MAGIC) & MASK;
        const shift = Number(i % 7n) + 1;
        acc = ((acc << BigInt(shift)) | (acc >> BigInt(64 - shift))) & MASK;
    }
    return acc;
}

function mixCorrect(data, key) {
    let acc = data;
    for (let i = 0n; i < 10n; i++) {
        acc ^= key * i;
        acc = (acc * MAGIC) & MASK;
        const shift = Number(i % 7n) + 1;
        acc = ((acc << BigInt(shift)) | (acc >> BigInt(64 - shift))) & MASK;
    }
    return acc;
}

const data = 0xFEDCBA98n * (2n**32n) + 0x76543210n;
const key  = 0xAAAABBBBn * (2n**32n) + 0xCCCCDDDDn;

const result  = mixBug(data, key);
const correct = mixCorrect(data, key);

if (result === correct) {
    process.stderr.write("AssertionError: global key equals local key\n");
    process.exit(1);
}
process.stderr.write(`ValueError: GLOBAL_KEY used instead of key parameter: got 0x${result.toString(16)} expected 0x${correct.toString(16)}\n`);
process.exit(1);
