**Error:** Pairwise_xor returned empty for single-element input {data}.

**Hint:** Single element case failure.
