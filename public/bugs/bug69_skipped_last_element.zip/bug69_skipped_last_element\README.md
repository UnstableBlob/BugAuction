**Error:** Last element skipped (range stops at len-1).

**Hint:** Skipped last element.
