**Error:** The script fails with a `SyntaxError: cannot assign to operator` because it uses a single equals sign `=` (assignment) instead of a double equals sign `==` (comparison) inside an `if` statement.

**Hint:** Assignment instead of comparison.
